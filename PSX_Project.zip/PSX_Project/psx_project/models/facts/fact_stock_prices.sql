{{ config(materialized='table') }}

SELECT
    s.stock_symbol,
    d.date_key,
    t.open_price,
    t.high_price,
    t.low_price,
    t.close_price
FROM {{ ref('stg_psx_data') }} t
JOIN {{ ref('dim_stock') }} s
    ON t.stock_symbol = s.stock_symbol
JOIN {{ ref('dim_date') }} d
    ON t.trade_date = d.date_key
    