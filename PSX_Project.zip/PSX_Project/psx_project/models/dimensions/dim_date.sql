{{ config(materialized='table') }}

WITH dates AS (
  SELECT DATEADD(day, seq4(), '2010-01-01') AS cal_date
  FROM TABLE(GENERATOR(ROWCOUNT => 6000))
)
SELECT
    cal_date AS date_key,
    YEAR(cal_date) AS year,
    MONTH(cal_date) AS month,
    DAY(cal_date) AS day,
    MONTHNAME(cal_date) AS month_name,
    DAYOFWEEK(cal_date) AS day_of_week,
    WEEKOFYEAR(cal_date) AS week_no
FROM dates
WHERE cal_date <= CURRENT_DATE()