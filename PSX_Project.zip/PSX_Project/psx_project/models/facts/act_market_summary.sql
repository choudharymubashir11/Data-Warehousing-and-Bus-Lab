{{ config(materialized='table') }}

SELECT
    stock_symbol,
    YEAR(trade_date) AS year,
    MONTH(trade_date) AS month,
    AVG(close_price) AS avg_close,
    MAX(close_price) AS max_close,
    MIN(close_price) AS min_close,
    SUM(high_price - low_price) AS volatility
FROM {{ ref('stg_psx_data') }}
GROUP BY 1,2,3