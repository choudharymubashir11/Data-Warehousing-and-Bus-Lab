{{ config(materialized='table') }}

SELECT DISTINCT
    TO_DATE(DATE) AS trade_date,   -- Corrected to uppercase
    SYMBOL AS stock_symbol,        -- Corrected to uppercase
    OPEN AS open_price,            -- Corrected to uppercase
    HIGH AS high_price,            -- Corrected to uppercase
    LOW AS low_price,              -- Corrected to uppercase
    CLOSE AS close_price           -- Corrected to uppercase
FROM {{ source('psx_raw', 'PSX_DATA') }}