{{ config(materialized='table') }}

SELECT DISTINCT
    stock_symbol,
    INITCAP(stock_symbol) AS stock_name
FROM {{ ref('stg_psx_data') }}